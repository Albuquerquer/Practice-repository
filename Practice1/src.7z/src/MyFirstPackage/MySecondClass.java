package MyFirstPackage;

public class MySecondClass
{
    private int i, j;

    public MySecondClass()
    {
        i = 1;
        j = 1;
    }

    public void setI (int i)
    {
        this.i = i;
    }

    public void setJ (int j)
    {
        this.j = j;
    }
	
    public int sum()
    {
        return i+j;
    }
}
